import { ApiService } from "./ApiService.js";

export class AuthService extends ApiService {
    constructor(baseUrl) {
        super(baseUrl)
    };

    async login(user) {
        const url = `${this.baseUrl}/users/login`
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(user),
        }
        let result = await this._internalFetcher(url, options);
        sessionStorage.setItem('accessToken', result.accessToken);
        sessionStorage.setItem('userId', result._id);
    };

    async register(user) {
        const url = `${this.baseUrl}/users/register`;
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(user),
        };
        let result = await this. _internalFetcher(url, options);
        sessionStorage.setItem('accessToken', result.accessToken);
        sessionStorage.setItem('userId', result._id);
    };

    async logout() {
        const url = `${this.baseUrl}/users/logout`;
        const options = {
            method: 'GET',
            headers: {
                'X-Authorization': sessionStorage.getItem('accessToken'),
            },
        }
        let result = await this. _internalFetcher(url, options);
        sessionStorage.removeItem('accessToken');
        sessionStorage.removeItem('userId');
        return result;
    };

    isUserLoggedIn() {
        return sessionStorage.getItem('accessToken') != undefined;
    }
}