export class ApiService {
    constructor(baseUrl) {
        this.baseUrl = baseUrl;
    };

    async _internalFetcher(url, options) {
        try {
            let response = await fetch(url, options);
            if(response.status === 200) {
                return await response.json();
            } else if(response.status === 204) {
                return undefined;
            } else {
                let result = await response.json()
                throw new Error(result.message);
            }
        } catch(err) {
            throw err;
        }
    }
}