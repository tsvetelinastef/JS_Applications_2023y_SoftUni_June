import { html } from "../../../node_modules/lit-html/lit-html.js";

export const navTemplate = (isLogged, logoutHandler) => html`
<a id="logo" href="/"
      ><img id="logo-img" src="./images/logo.png" alt=""
    /></a>

    <nav>
      <div>
        <a href="/dashboard">Motorcycles</a>
        <a href="/search">Search</a>
      </div>

    ${isLogged
      ? html`
      <div class="user">
          <a href="/create">Add Motorcycle</a>
          <a href="javascript:void(0)" @click=${logoutHandler}>Logout</a>
      </div>`
      : html`
      <div class="guest">
          <a href="/login">Login</a>
          <a href="/register">Register</a>
          
      </div>`
    }
    </nav>`