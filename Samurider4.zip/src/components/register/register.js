import page from '../../../node_modules/page/page.mjs';
export class RegisterPage {
    constructor(templateFunction, render, authService) {
        this.templateFunction = templateFunction;
        this.render = render;
        this.authService = authService;
        this.showView = this._showView.bind(this);
        this.submitHandler = this._submitHandler.bind(this);
    };

    async _showView(ctx, next) {
        let template = this.templateFunction(this.submitHandler);
        this.render(template);
        next();
    }

    async _submitHandler(e) {
        e.preventDefault();

        let form = e.target;
        let formData = new FormData(form);
        let email = formData.get('email');
        let password = formData.get('password');
        let rePass = formData.get('re-password');

        if (email == '' || password == '' || rePass == '') {
            alert('Email and Password must not be empty!');
            return;
        };

        let user = { email, password };

        try {
            const result = await this.authService.register(user);
            page.show('/');
        } catch(err) {
            alert(err.message)
        }
    }
}