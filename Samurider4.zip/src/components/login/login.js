import page from "../../../node_modules/page/page.mjs";
export class loginPage {
    constructor(templateFunction, render, authService) {
        this.templateFunction = templateFunction;
        this.render = render;
        this.authService = authService;
        this.showView = this._showView.bind(this);
        this.loginHandler = this._loginHandler.bind(this);
    }

    async _showView(ctx, next) {
        let template = this.templateFunction(this.loginHandler);
        this.render(template);
        next();
    }

    async _loginHandler(e) {
        e.preventDefault();
        let form = e.target;
        let formData = new FormData(form);
        let email = formData.get('email');
        let password = formData.get('password');

        if (email == '' || password == '') {
            alert('Email and Password must not be empty!');
            return;
        }

        let user = { email, password }
        try {
            let result = await this.authService.login(user);
            page.show('/');
        } catch(err) {
            alert(err.message);
        };
    }
}