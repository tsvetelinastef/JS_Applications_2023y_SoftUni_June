import page from "../../../node_modules/page/page.mjs";
export class SearchPage{
    constructor(crudService, templateFunction, render) {
        this.templateFunction = templateFunction;
        this.render = render;
        this.crudService = crudService;
        this.showView = this._showView.bind(this);
        this.submitHandler = this._submitHandler.bind(this);
    }

    async _showView(ctx) {
        let queryString = ctx.querystring;
        let motorcycles = [];
        if (queryString != '') {
            let queryArr = queryString.split('=');
            let value = queryArr[1];
            motorcycles = await this.crudService.searchMotorcycles(value);
        }
        let template = this.templateFunction(this.submitHandler, motorcycles);
        this.render(template);
    }

    async _submitHandler(e) {
        e.preventDefault();
        let form = e.target;
        let formData = new FormData(form);
        let searchValue = formData.get('search');

        if (searchValue == '') {
            alert('Field must not be empty!');
            return
        }
        page.show(`/search?model=${searchValue}`)
    }
}