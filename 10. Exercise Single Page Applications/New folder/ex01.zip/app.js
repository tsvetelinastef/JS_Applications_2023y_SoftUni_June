import { showHome } from './topic.js';

document.getElementById('homeLink').addEventListener('click', showHome);

showHome();
